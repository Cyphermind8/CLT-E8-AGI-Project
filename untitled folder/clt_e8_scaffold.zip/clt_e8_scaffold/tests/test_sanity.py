import subprocess, sys, json, pathlib, os

def test_improves():
    # Run with few generations to keep test quick
    cfg_text = """
seed: 123
population_size: 30
generations: 25
elitism: 2
mutation_rate: 0.3
mutation_scale: 0.12
task:
  name: quadratic_fit
  n_points: 40
  noise_std: 0.05
fitness:
  type: neg_mse
"""
    path = pathlib.Path("tmp_test")
    path.mkdir(exist_ok=True)
    (path/"config.yaml").write_text(cfg_text)

    # Run experiment
    r = subprocess.run([sys.executable, "scripts/run_experiment.py", "--config", str(path/"config.yaml")],
                       capture_output=True, text=True, cwd=pathlib.Path("."))
    assert r.returncode == 0, r.stderr

    # Check logs exist and best fitness improves over time
    log = pathlib.Path("runs/seed_123/evolution.jsonl")
    assert log.exists()
    lines = [json.loads(x) for x in log.read_text().splitlines()]
    assert len(lines) >= 5
    assert lines[-1]["best_fitness"] >= lines[0]["best_fitness"]
