# CLT‑E8 Research Scaffold

A **grounded**, testable scaffold to explore your *CLT‑E8* theory without illusion traps.

## Principles (Guardrails)
1. **No implied capability** — every claim must be backed by a **replicable artifact** (logs, metrics, plots).
2. **Evidence gates** — promotion from idea → prototype → claim requires passing pre‑defined tests.
3. **Separation of concerns** — theory (CLT‑E8 axioms) is separate from code that runs experiments.
4. **Ablations first** — always include a dumb baseline and an ablation study before attributing gains to CLT‑E8.
5. **Reproducibility** — `config.yaml` fully specifies an experiment; results logged as JSONL with seeds.

## What’s here
- `clt_e8/` — minimal components:
  - `theory.py` — placeholder to write your CLT‑E8 axioms & mappings to observables.
  - `agent.py` — simple parametric "agent" with genome → behavior → fitness.
  - `evaluator.py` — tasks & metrics (starts with quadratic regression as a toy).
  - `evolution.py` — evolutionary loop (selection, mutation, elitism, logs).
  - `memory.py` — run log writer (JSONL) + checkpoint I/O.
- `scripts/run_experiment.py` — runs a tiny population evolution you can extend.
- `config.yaml` — single source of truth for experiment knobs.
- `tests/test_sanity.py` — proves improvement vs. baseline on a toy task.

## Evidence gates (initial)
- **Gate A (improvement)**: best fitness after N generations must improve > given threshold.
- **Gate B (reproducibility)**: re‑run with the same seed reproduces within tolerance.
- **Gate C (ablation)**: disable the CLT‑E8 inductive bias — performance should drop.

> Replace the toy task with your actual CLT‑E8 constructs as you formalize them.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
python scripts/run_experiment.py --config config.yaml
pytest -q
```
