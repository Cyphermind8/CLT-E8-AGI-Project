import argparse, random, yaml, pathlib
from clt_e8.agent import Agent
from clt_e8.theory import CLTE8Axioms
from clt_e8.evaluator import make_quadratic_dataset, fitness_quadratic
from clt_e8.evolution import evolve
from clt_e8.memory import JSONLWriter

def main(cfg_path):
    cfg = yaml.safe_load(open(cfg_path, "r", encoding="utf-8"))
    seed = cfg["seed"]
    rng = random.Random(seed)

    # Data
    xs, ys = make_quadratic_dataset(seed, cfg["task"]["n_points"], cfg["task"]["noise_std"])
    def fitness(genome):
        return fitness_quadratic(genome, xs, ys)

    # Axioms (start at zero; you can tune)
    axioms = CLTE8Axioms(compression_bias=0.5)

    # Init population around small random params
    pop = [Agent([rng.uniform(-1,1) for _ in range(3)], axioms) for _ in range(cfg["population_size"])]

    logs_dir = pathlib.Path("runs") / ("seed_" + str(seed))
    logger = JSONLWriter(logs_dir / "evolution.jsonl")

    best, best_fit = evolve(
        population=pop,
        fitness_fn=fitness,
        generations=cfg["generations"],
        elitism=cfg["elitism"],
        mutation_rate=cfg["mutation_rate"],
        mutation_scale=cfg["mutation_scale"],
        rng=rng,
        logger=logger
    )
    logger.close()

    print("BEST_FITNESS", round(best_fit, 6), "BEST_GENOME", [round(x, 4) for x in best.genome])

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()
    main(args.config)
