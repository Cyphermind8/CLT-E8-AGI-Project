from dataclasses import dataclass, asdict
import random
from typing import List
from .theory import apply_biases_to_genome, CLTE8Axioms

@dataclass
class Agent:
    # Simple "genome": parameters [a,b,c] for a quadratic
    genome: List[float]
    axioms: CLTE8Axioms

    def mutate(self, rate: float, scale: float, rng: random.Random) -> "Agent":
        new_g = []
        for g in self.genome:
            if rng.random() < rate:
                g = g + rng.gauss(0.0, scale)
            new_g.append(g)
        new_g = apply_biases_to_genome(new_g, self.axioms)
        return Agent(new_g, self.axioms)

    def as_dict(self):
        return {"genome": self.genome, "axioms": asdict(self.axioms)}
