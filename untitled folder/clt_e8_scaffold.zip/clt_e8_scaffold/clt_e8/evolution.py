import random, json, time
from typing import List, Callable
from .agent import Agent
from .memory import JSONLWriter

def evolve(population: List[Agent],
           fitness_fn: Callable,
           generations: int,
           elitism: int,
           mutation_rate: float,
           mutation_scale: float,
           rng: random.Random,
           logger: JSONLWriter):

    # Evaluate initial fitness
    fitnesses = [fitness_fn(a.genome) for a in population]
    for gen in range(generations):
        # Selection: keep top-k (elitism), tournament for the rest
        ranked = sorted(zip(population, fitnesses), key=lambda t: t[1], reverse=True)
        elites = [x for x,_ in ranked[:elitism]]
        # Tournament selection
        def pick():
            i, j = rng.randrange(len(population)), rng.randrange(len(population))
            return population[i] if fitnesses[i] > fitnesses[j] else population[j]
        children = []
        while len(children) < len(population) - elitism:
            parent = pick()
            child = parent.mutate(mutation_rate, mutation_scale, rng)
            children.append(child)
        population = elites + children
        fitnesses = [fitness_fn(a.genome) for a in population]

        # Logging
        best = max(fitnesses)
        mean = sum(fitnesses)/len(fitnesses)
        logger.write({
            "gen": gen,
            "best_fitness": best,
            "mean_fitness": mean,
            "best_genome": population[fitnesses.index(best)].genome,
        })

    # return best agent and fitness
    best_idx = fitnesses.index(max(fitnesses))
    return population[best_idx], fitnesses[best_idx]
