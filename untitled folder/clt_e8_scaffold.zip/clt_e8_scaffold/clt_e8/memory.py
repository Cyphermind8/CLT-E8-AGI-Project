import json, pathlib, datetime

class JSONLWriter:
    def __init__(self, path):
        self.path = pathlib.Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.f = self.path.open("a", encoding="utf-8")

    def write(self, obj):
        obj = dict(obj)
        obj["ts"] = datetime.datetime.utcnow().isoformat() + "Z"
        self.f.write(json.dumps(obj) + "\n")
        self.f.flush()

    def close(self):
        self.f.close()
