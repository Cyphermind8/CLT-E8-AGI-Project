import random, math
from typing import Tuple, List

def make_quadratic_dataset(seed: int, n_points: int, noise_std: float) -> Tuple[List[float], List[float]]:
    rng = random.Random(seed)
    # Ground truth params:
    a_true, b_true, c_true = 0.8, -0.3, 0.5
    xs, ys = [], []
    for i in range(n_points):
        x = -2.0 + 4.0 * i/(n_points-1)
        y = a_true*x*x + b_true*x + c_true + rng.gauss(0.0, noise_std)
        xs.append(x); ys.append(y)
    return xs, ys

def fitness_quadratic(genome, xs, ys):
    a,b,c = genome
    mse = 0.0
    for x,y in zip(xs,ys):
        yhat = a*x*x + b*x + c
        mse += (yhat - y)**2
    mse /= len(xs)
    return -mse  # higher is better
