# Metrics & Thresholds (v1)

These definitions make our progress falsifiable.

## Core Metrics
- **Grounded Correctness**: Percent of tasks solved with Critic-verified outputs (unit tests / checks). **Target ≥ 95%** on curated math/code suites.
- **Generalization from Demos**: After ≤5 demonstration trajectories, the system solves novel instances of the tool’s task. **Target ≥ 80%** success on held-out set.
- **Memory Utility (E8 vs Baseline)**: Improvement of success rate and/or latency with E8 multi-head retrieval enabled vs single-head. **Target: +10% accuracy or −20% latency.**
- **Contradiction Handling**: Fraction of detected conflicts auto-resolved by TMS-guided revision. **Target ≥ 70%**.
- **Self-Revision Efficacy**: On failure, the agent proposes and executes a revised plan with higher Coherence that succeeds. **Target ≥ 60%**.
- **Coherence–Success Correlation**: Pearson r between Coherence score and task success across runs. **Target r ≥ 0.6**.

## Component Ablations
Ablate the following and measure degradation:
1. Single-head only (no E8 multi-head).
2. No slip rotations (no phase penalties).
3. No TMS (no contradiction tracking).
4. No Critic (no tool checks).
5. No World Model (no simulation).

**Pass**: Each ablation measurably reduces performance (accuracy, stability, or sample efficiency).
