# Glossary (Operational)

- **Coherence**: Scalar objective combining information gain, module agreement, and contradiction penalties.
- **SlipState**: Immutable, append-only state node with parents, provenance, and head-wise encodings.
- **Phase Penalty**: Retrieval weight reduction due to contradictions or failed verification.
- **Head**: One projection axis in the multi-head embedding space.
- **TMS**: Truth Maintenance System (assumptions, justifications, derived facts, conflicts).
