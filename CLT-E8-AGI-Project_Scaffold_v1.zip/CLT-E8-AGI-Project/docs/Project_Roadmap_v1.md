# Project Roadmap (v1)

## Week 1–2
- Workspace + SlipState graph
- Multi-head projections + slip rotations
- Critic (calculator & code exec)
- Tests for above

## Month 1
- CSV demo end-to-end
- Procedural skill capture
- Memory ablation report (E8 vs single-head)
- Minimum safety (sandbox + logs)

## Month 3
- Add World Model + TMS
- Plan revision on contradictions
- Publish internal ablation report

## Month 6
- Few-shot new tool learning
- Skill composition library
- Prep public-facing reproducible benchmarks

## Year 1
- Modular hybrid agent with documented wins over baselines
- Community-ready repo with reproducible workflows
- Draft preprint on coherence-driven AGI
