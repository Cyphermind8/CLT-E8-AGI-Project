## Changelog

- 2025-09-10 – v0.1: Initial scaffold generated.
