"""
planner_v1.py — Plan sampling, simulation, verification; rank by Coherence.
"""
def plan(options):
    # Placeholder plans
    return [{"steps": ["do_x", "do_y"]}]
