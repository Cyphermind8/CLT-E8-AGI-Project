"""
world_model_v1.py — Minimal "what-if" simulator with typed pre/postconditions.
"""
def rollout(plan):
    # Placeholder simulation results
    return {"sim_ok": True, "cost_est": 1.0}
