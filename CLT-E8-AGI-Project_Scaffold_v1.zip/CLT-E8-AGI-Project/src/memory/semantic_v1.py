"""Multi-head vector store interface (FAISS later)."""
