"""Skill library (macros with success metrics)."""
