"""Append-only episodic traces."""
