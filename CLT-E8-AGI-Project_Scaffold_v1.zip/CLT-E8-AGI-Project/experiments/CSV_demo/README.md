# CSV Demo (scaffold)

Goal: Compute rolling z-score per group; flag outliers; plot; explain method.

This folder will hold sample CSVs, generated code, and run logs once implemented.
