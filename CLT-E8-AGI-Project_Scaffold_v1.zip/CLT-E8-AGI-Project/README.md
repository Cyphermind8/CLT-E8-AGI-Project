# CLT–E8 AGI Development Project

This repository scaffolds a coherence-first AGI prototype grounded in Coherence Lattice Theory (CLT–E8).
It implements SlipStates (immutable, append-only memory), multi-head (E8-inspired) embeddings with phase-gated retrieval,
a symbolic reasoner with a Truth Maintenance System (TMS), a lightweight world model, a planner that maximizes Coherence,
and a Critic that verifies claims via external tools.

**Created:** 2025-09-10

## Structure
- `docs/` – Master Instructions, Theory Mapping, metrics, experiment design
- `src/` – Core modules (workspace, embeddings, memory, symbolic, world_model, planner, critic, governor, tools)
- `schemas/` – JSON schemas (SlipState, records)
- `config/` – Tunables (heads, thresholds, gates)
- `tests/` – Unit tests for each component
- `experiments/CSV_demo/` – End-to-end demo scaffold
- `logs/`, `experiment_logs/` – Outputs and run logs

## Quick Start (conceptual)
1. Configure `config/default.yaml`.
2. Run `python src/main_v1.py` to execute the control loop in dry-run mode.
3. Explore `experiments/CSV_demo/README.md` for the first end-to-end task.
4. Check `experiment_logs/` and `logs/` for coherence scores and audit trails.

See `docs/Master_Instructions.docx` and `docs/CLT-E8_Theory_Mapping_v1.docx` for context.
