﻿#requires -Version 3
[CmdletBinding()]
Param(
  [int]$Cycles = 30,
  [int]$Minutes = 180,
  [switch]$Strict,
  [string[]]$Targets = @('src\llm\planner_llm.py','src\llm\critic_llm.py','src\workspace_v1.py'),
  [int]$Population = 1,
  [int]$Determinism = 1,
  [int]$BenchTimeout = 300,
  [int]$PytestTimeout = 120
)

function Join-Args([string[]]$arr) {
  $q = @()
  foreach($a in $arr) {
    if ($null -eq $a) { continue }
    if ($a -match '[\s"]') { $q += '"' + ($a -replace '"','`"') + '"' } else { $q += $a }
  }
  return ($q -join ' ')
}

$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$logs    = Join-Path $Root 'logs'
$reports = Join-Path $Root 'reports'
if (-not (Test-Path $logs))    { New-Item -ItemType Directory -Path $logs    | Out-Null }
if (-not (Test-Path $reports)) { New-Item -ItemType Directory -Path $reports | Out-Null }

$venvPy = Join-Path $Root '.venv\Scripts\python.exe'
$python = (Test-Path $venvPy) ? $venvPy : 'python.exe'  # PS5-safe? -> emulate ternary:
if (-not (Test-Path $venvPy)) { $python = 'python.exe' } else { $python = $venvPy }

$sessionId = Get-Date -Format 'yyyyMMdd_HHmmss'
$ciLog = Join-Path $logs ("ci_session_{0}.log" -f $sessionId)

function Write-CILog([string]$msg) {
  $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
  $line = "[{0}] {1}" -f $ts, $msg
  $line | Tee-Object -FilePath $ciLog -Append
}

Write-CILog "[CI] session $sessionId in $Root"
Write-Host "Tip: tail latest:  Get-Content (Get-ChildItem .\logs\*.log | Sort-Object LastWriteTime | Select -Last 1).FullName -Tail 120 -Wait"

function Start-LoggedProcess {
  Param(
    [string]$FilePath,
    [string]$ArgumentLine,
    [int]$TimeoutSec,
    [string]$StdOutPath,
    [string]$StdErrPath
  )
  if (-not (Test-Path $StdOutPath)) { '' | Out-File -FilePath $StdOutPath -Encoding utf8 }
  if (-not (Test-Path $StdErrPath)) { '' | Out-File -FilePath $StdErrPath -Encoding utf8 }

  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $FilePath
  $psi.Arguments = $ArgumentLine          # PS5-safe (string), not ArgumentList
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.CreateNoWindow = $true

  $p = New-Object System.Diagnostics.Process
  $p.StartInfo = $psi

  $outWriter = [System.IO.StreamWriter]::new($StdOutPath, $true, [System.Text.Encoding]::UTF8)
  $errWriter = [System.IO.StreamWriter]::new($StdErrPath, $true, [System.Text.Encoding]::UTF8)

  $p.add_OutputDataReceived({ param($s,$e) if ($e.Data) { $outWriter.WriteLine($e.Data) } })
  $p.add_ErrorDataReceived( { param($s,$e) if ($e.Data) { $errWriter.WriteLine($e.Data) } })

  $null = $p.Start()
  $p.BeginOutputReadLine()
  $p.BeginErrorReadLine()

  $exited = $p.WaitForExit([int]$TimeoutSec * 1000)
  if (-not $exited) {
    try { $p.Kill() } catch {}
    $outWriter.Flush(); $errWriter.Flush()
    $outWriter.Dispose(); $errWriter.Dispose()
    return @{ TimedOut = $true; ExitCode = $null }
  }

  $outWriter.Flush(); $errWriter.Flush()
  $outWriter.Dispose(); $errWriter.Dispose()
  return @{ TimedOut = $false; ExitCode = $p.ExitCode }
}

function Seed-Baselines {
  Write-CILog "[CI] Seeding baselines..."
  $seedOut = Join-Path $logs ("run_all_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
  $seedErr = $seedOut
  $seedScript = Join-Path $Root 'bench\run_all.py'
  if (Test-Path $seedScript) {
    $args = @('bench\run_all.py')
    $argLine = Join-Args $args
  } else {
    # Fallback: just run the main bench with determinism=2
    $args = @('bench\run_bench.py','--determinism','2')
    $argLine = Join-Args $args
  }
  $res = Start-LoggedProcess -FilePath $python -ArgumentLine $argLine -TimeoutSec 900 -StdOutPath $seedOut -StdErrPath $seedErr
  if ($res.TimedOut) { Write-CILog "[CI] Baseline seed timed out; continuing anyway." }
}

function Invoke-GatedLoop([string]$target) {
  $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
  $glOut = Join-Path $logs ("gated_loop_{0}.out.log" -f $ts)
  $glErr = Join-Path $logs ("gated_loop_{0}.err.log" -f $ts)
  $glLog = Join-Path $logs ("gated_loop_{0}.log" -f $ts)  # consumer tools look for this pattern

  $args = @(
    'self_mod\gated_loop.py',
    '--target', $target,
    '--population', "$Population",
    '--determinism', "$Determinism",
    '--bench-timeout', "$BenchTimeout",
    '--pytest-timeout', "$PytestTimeout",
    '--min-rate','1.0',
    '--min-equal-rate-speedup','0.03'
  )
  if ($Strict.IsPresent) {
    $args += @('--micro-gate','--micro-speedup','0.03')
  }
  $argLine = Join-Args $args

  Write-CILog "[CI] launching: $python $argLine"
  $timeoutSec = [Math]::Max($BenchTimeout, $PytestTimeout) + 120
  $res = Start-LoggedProcess -FilePath $python -ArgumentLine $argLine -TimeoutSec $timeoutSec -StdOutPath $glOut -StdErrPath $glErr

  if ($res.TimedOut) {
    Write-CILog "[CI] result: accepted=False nochange=False pytest=False bench=False micro=False hardtimeout=True exit= log=$glLog"
  } else {
    Write-CILog "[CI] process exited code $($res.ExitCode). Logs: $glOut / $glErr"
    Write-CILog "[CI] result: accepted=False nochange=Unknown pytest=Unknown bench=Unknown micro=Unknown hardtimeout=False exit=$($res.ExitCode) log=$glLog"
  }
}

# ---- main ----
Write-CILog "[CI] *** WATCHDOG ENABLED ***"
Seed-Baselines

$stopAt = (Get-Date).AddMinutes($Minutes)
for ($i=1; $i -le $Cycles; $i++) {
  foreach ($t in $Targets) {
    if ((Get-Date) -ge $stopAt) {
      Write-CILog "[CI] time budget reached. Ending early at cycle $i."
      break
    }
    Write-CILog ("[CI] --- Cycle {0} on {1} ---" -f $i, $t)
    Invoke-GatedLoop -target $t
  }
}

# Emit a small summary blob to stdout for tools that scrape it
$summaryJsonPath = Join-Path $reports ("ci_session_{0}.json" -f $sessionId)
$summaryBlob = "{`"session_log`": `"$($ciLog.Replace('\','\\'))`", `"summary_json`": `"$($summaryJsonPath.Replace('\','\\'))`"}"
Write-CILog ("[CI] Finished. Summary: {0}" -f $summaryJsonPath)
$summaryBlob | Out-Host