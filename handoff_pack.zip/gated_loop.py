﻿# FILE: self_mod/gated_loop.py
from __future__ import annotations

import argparse
import ast
import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------- Workspace constants ----------
WS_ROOT = Path("C:\\AI_Project") if os.name == "nt" else Path.cwd()
REPORTS_DIR = WS_ROOT / "reports"
LOGS_DIR = WS_ROOT / "logs"
BACKUP_DIR = WS_ROOT / "backup"
DATA_DIR = WS_ROOT / "data"
for d in (REPORTS_DIR, LOGS_DIR, BACKUP_DIR, DATA_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ---------- Tolerant '# FILE:' extractor (fenced or unfenced), preserves order ----------
_FENCED = re.compile(
    r"```(?:[a-zA-Z0-9_+\-]*\n)?#\s*FILE:\s*(?P<path>[^\r\n]+)\r?\n(?P<body>.*?)(?:```|\Z)",
    re.DOTALL | re.MULTILINE,
)
_UNFENCED = re.compile(
    r"^#\s*FILE:\s*(?P<path>[^\r\n]+)\r?\n(?P<body>.*?)(?=^#\s*FILE:|\Z)",
    re.DOTALL | re.MULTILINE,
)

def _ts() -> str: return time.strftime("%Y%m%d_%H%M%S", time.localtime())

def _norm_rel(path: str) -> str:
    p = path.strip().replace("\\\\", "/").replace("\\", "/")
    if os.path.isabs(p) or re.match(r"^[A-Za-z]:", p):
        raise ValueError(f"Absolute paths not allowed: {path}")
    p = os.path.normpath(p).replace("\\\\", "/").replace("\\", "/")
    if p.startswith("../") or p == "..":
        raise ValueError(f"Path escapes workspace: {path}")
    return p

def extract_blocks(text: str) -> List[Tuple[str, str]]:
    matches: List[Tuple[int, str, str]] = []
    for m in _FENCED.finditer(text):
        matches.append((m.start(), m.group("path"), m.group("body")))
    if not matches:
        for m in _UNFENCED.finditer(text):
            matches.append((m.start(), m.group("path"), m.group("body")))
    matches.sort(key=lambda t: t[0])
    return [(_norm_rel(p), b.rstrip("\n") + "\n") for _, p, b in matches]

# ---------- Utilities ----------
def run(cmd: List[str], timeout_s: int, cwd: Optional[Path] = None) -> Tuple[int, str]:
    proc = subprocess.Popen(cmd, cwd=str(cwd) if cwd else None,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, shell=False)
    try:
        out, _ = proc.communicate(timeout=timeout_s)
        return proc.returncode, out
    except subprocess.TimeoutExpired:
        proc.kill()
        return -1, f"[TIMEOUT] {' '.join(cmd)}"

def latest_report(prefix: str) -> Optional[Path]:
    reports = sorted(REPORTS_DIR.glob(f"{prefix}_*.json"),
                     key=lambda p: p.stat().st_mtime, reverse=True)
    return reports[0] if reports else None

def load_env_from_dotenv():
    env_path = WS_ROOT / ".env"
    if not env_path.exists(): return
    for line in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#"): continue
        if "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

def openai_chat(messages: List[Dict[str, str]], model: str, base_url: str,
                api_key: str, max_tokens: int = 1500) -> str:
    # Minimal, highly-compatible payload for LM Studio
    import urllib.request
    url = base_url.rstrip("/") + "/chat/completions"
    payload = {"model": model, "messages": messages, "temperature": 0,
               "max_tokens": max_tokens}
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    })
    with urllib.request.urlopen(req, timeout=300) as resp:
        body = resp.read().decode("utf-8", errors="ignore")
    parsed = json.loads(body)
    return parsed["choices"][0]["message"]["content"]

def ast_equal(a_src: str, b_src: str) -> bool:
    try:
        return ast.dump(ast.parse(a_src)) == ast.dump(ast.parse(b_src))
    except Exception:
        return a_src.strip() == b_src.strip()

@dataclass
class BenchSummary:
    rate: float; latency_s: float
    determinism_ok: Optional[bool] = None
    path: Optional[Path] = None

@dataclass
class MicroSummary:
    steps: float; latency_ms: float
    path: Optional[Path] = None

def parse_bench_report(p: Path) -> BenchSummary:
    j = json.loads(p.read_text(encoding="utf-8"))
    s = j["outputs"]["summary"]
    return BenchSummary(rate=float(s["success"]["rate"]),
                        latency_s=float(s["latency"]["avg_s"]),
                        determinism_ok=bool(s.get("determinism_ok", False)),
                        path=p)

def parse_micro_report(p: Path) -> MicroSummary:
    j = json.loads(p.read_text(encoding="utf-8"))
    s = j["outputs"]["summary"]["aggregate"]
    return MicroSummary(steps=float(s["avg_steps"]),
                        latency_ms=float(s["avg_latency_ms"]),
                        path=p)

def run_pytest(timeout_s: int) -> bool:
    rc, out = run([sys.executable, "-m", "pytest", "-q"], timeout_s=timeout_s, cwd=WS_ROOT)
    print(out); return rc == 0

def run_bench(determinism_runs: int, timeout_s: int) -> BenchSummary:
    cmd = [sys.executable, str(WS_ROOT / "bench" / "run_bench.py"),
           "--determinism", str(determinism_runs)]
    rc, out = run(cmd, timeout_s=timeout_s, cwd=WS_ROOT)
    print(out)
    m = re.search(r'"json":\s*"([^"]+bench_\d+\.json)"', out)
    p = Path(m.group(1)) if m else latest_report("bench")
    if p and p.exists(): return parse_bench_report(p)
    raise RuntimeError("Bench report not found.")

def run_micro(runs: int, timeout_s: int) -> MicroSummary:
    cmd = [sys.executable, "-m", "bench.run_workspace_micro", "--runs", str(runs)]
    rc, out = run(cmd, timeout_s=timeout_s, cwd=WS_ROOT)
    print(out)
    m = re.search(r'"json":\s*"([^"]+micro_workspace_\d+\.json)"', out)
    p = Path(m.group(1)) if m else latest_report("micro_workspace")
    if p and p.exists(): return parse_micro_report(p)
    raise RuntimeError("Micro report not found.")

# ---------- Snapshots & rollback ----------
@dataclass
class FileSnapshot:
    path: Path; existed: bool; content: Optional[bytes]

def write_text_with_snapshot(path: Path, content: str) -> FileSnapshot:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists(): snap = FileSnapshot(path, True, path.read_bytes())
    else:             snap = FileSnapshot(path, False, None)
    path.write_text(content, encoding="utf-8"); return snap

def rollback(snapshots: List[FileSnapshot]) -> None:
    for snap in reversed(snapshots):
        if snap.existed and snap.content is not None:
            snap.path.write_bytes(snap.content)
        else:
            try:
                if snap.path.exists(): snap.path.unlink()
            except Exception: pass

def backup_file(path: Path) -> Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    name = f"{path.stem}_{_ts()}{path.suffix}"; dest = BACKUP_DIR / name
    shutil.copy2(path, dest) if path.exists() else None
    return dest

# ---------- Logging (tee stdout to file) ----------
class _Tee:
    def __init__(self, a, b): self.a = a; self.b = b
    def write(self, s): self.a.write(s); self.b.write(s)
    def flush(self): self.a.flush(); self.b.flush()

def _install_stdout_tee() -> Path:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOGS_DIR / f"gated_loop_{_ts()}.log"
    f = open(log_path, "a", encoding="utf-8")
    sys.stdout = _Tee(sys.stdout, f)
    return log_path

# ---------- Prompt builders ----------
def make_prompt_for_target(target: Path, baseline_note: str = "") -> List[Dict[str, str]]:
    src = target.read_text(encoding="utf-8", errors="ignore") if target.exists() else ""
    system = (
        "You are an automated engineer.\n"
        "OUTPUT ONLY FILE BLOCKS. Each block is a full file as either a fenced code block "
        "or unfenced text beginning with '# FILE: <relative/path>'.\n"
        "No prose outside blocks.\n"
        "Absolute rules:\n"
        " - Keep existing string/regex literals unless strictly necessary.\n"
        " - Your patch MUST parse as Python (no unterminated strings).\n"
        " - Prefer minimal diffs that reduce tokens/latency; keep public contracts identical.\n"
    )
    user = (
        f"Project root: {WS_ROOT}\n"
        f"Primary target: {target.as_posix()}\n"
        f"{baseline_note}\n"
        "Example:\n"
        "```python\n# FILE: src/workspace_v1.py\n<full file>\n```\n"
        "# FILE: self_mod/another.py\n<full file>\n"
    )
    return [{"role":"system","content":system},
            {"role":"user","content":user},
            {"role":"user","content":src}]

def make_retry_prompt(prev_reply: str, error_msg: str) -> List[Dict[str, str]]:
    system = (
        "Your last patch failed a syntax preflight. You must return corrected files only.\n"
        "Rules: keep the same intent, fix syntax, avoid touching string literal quoting unless required."
    )
    user = f"Error was:\n{error_msg}\n\nReturn corrected files (same format)."
    return [{"role":"system","content":system},{"role":"user","content":user},{"role":"user","content":prev_reply}]

# ---------- Preflight: AST parse before write ----------
def preflight_ast(files: List[Tuple[str, str]]) -> Optional[str]:
    """
    Returns None if all OK; otherwise returns a human-readable error string
    describing the first syntax failure.
    """
    for rel, body in files:
        if rel.endswith(".py"):
            try:
                ast.parse(body, filename=rel)
            except SyntaxError as e:
                return f"{rel}:{e.lineno}:{e.offset} {e.msg}"
    return None

# ---------- Main gated loop ----------
def main():
    log_path = _install_stdout_tee()
    print(f"[Log] Writing to {log_path.as_posix()}")

    load_env_from_dotenv()
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True)
    ap.add_argument("--population", type=int, default=1)
    ap.add_argument("--determinism", type=int, default=2)
    ap.add_argument("--bench-timeout", type=int, default=240)
    ap.add_argument("--pytest-timeout", type=int, default=120)
    ap.add_argument("--min-rate", type=float, default=1.0)
    ap.add_argument("--min-equal-rate-speedup", type=float, default=0.03)
    ap.add_argument("--micro-gate", action="store_true")
    ap.add_argument("--micro-speedup", type=float, default=0.03)
    args = ap.parse_args()

    base_url = os.getenv("OPENAI_BASE_URL", "http://127.0.0.1:1234/v1")
    api_key  = os.getenv("OPENAI_API_KEY", "lm-studio")
    model    = os.getenv("MODEL", "openai/gpt-oss-20b")

    print(f">>> Using MODEL={model} via {base_url}")
    print(f">>> Gate timeouts: pytest={args.pytest_timeout}s, bench={args.bench_timeout}s, micro=90s")
    if args.micro_gate:
        print(f">>> Micro-gate enabled: speedup ≥ {args.micro_speedup*100:.1f}%, runs=3")

    # Baselines
    if not run_pytest(args.pytest_timeout):
        print("[Abort] pytest failed at baseline."); sys.exit(2)
    b0 = run_bench(args.determinism, args.bench_timeout)
    m0 = run_micro(3, 90)
    print(f"[Baseline] Bench: rate={b0.rate:.3f}, latency={b0.latency_s:.3f}s (min_rate={args.min_rate:.3f})  {b0.path.name if b0.path else ''}")
    print(f"[Baseline] Micro: steps={m0.steps:.2f}, latency={m0.latency_ms:.3f} ms  {m0.path.name if m0.path else ''}")

    target = WS_ROOT / args.target
    cycles = max(1, args.population)

    for cycle in range(1, cycles+1):
        print(f"\n[Cycle {cycle}] Proposing patch for {args.target} ...")
        messages = make_prompt_for_target(target, baseline_note=f"Baseline bench avg={b0.latency_s:.3f}s at rate={b0.rate:.3f}.")
        try:
            reply = openai_chat(messages, model=model, base_url=base_url, api_key=api_key, max_tokens=2000)
        except Exception as e:
            print(f"[Cycle {cycle}] LLM error: {e}"); continue

        # Audit candidate text (always saved for traceability)
        cand_name = f"{target.stem}_cand_{_ts()}{target.suffix}"
        cand_path = target.parent / cand_name
        cand_path.write_text(reply, encoding="utf-8")
        print(f"[Cycle {cycle}] Candidate written to {cand_path.as_posix()}")

        def _extract_or_single(body_text: str) -> List[Tuple[str,str]]:
            files = extract_blocks(body_text)
            if files: return files
            # single-file mode: full content for target
            body = body_text
            m = re.search(r"#\s*FILE:\s*.*\n", body)
            if m: body = body[m.end():]
            return [(target.as_posix().replace("\\","/"), body)]

        # Try once, then optionally one retry if syntax preflight fails
        attempt = 1
        while attempt <= 2:
            files = _extract_or_single(reply)
            # --- preflight AST syntax check before writing ---
            err = preflight_ast(files)
            if err:
                if attempt == 1:
                    print(f"[Preflight] Syntax error detected: {err}  -> retrying once with correction prompt.")
                    try:
                        reply = openai_chat(make_retry_prompt(reply, err), model=model,
                                            base_url=base_url, api_key=api_key, max_tokens=2000)
                        attempt += 1
                        continue
                    except Exception as e:
                        print(f"[Preflight] Retry LLM error: {e}")
                        break
                else:
                    print(f"[Preflight] Syntax still invalid after retry: {err}")
                    files = []  # force rejection
            # If here, either OK or we’ll reject due to empty files
            break

        if not files:
            print("[Gate] Candidate rejected pre-write due to syntax. Skipping cycle.")
            continue

        snapshots: List['FileSnapshot'] = []
        try:
            # Write files with snapshots
            changed_paths: List[Path] = []
            print(f"[Extractor] Patch with {len(files)} file(s).")
            for rel, body in files:
                abs_path = WS_ROOT / rel
                snapshots.append(write_text_with_snapshot(abs_path, body))
                changed_paths.append(abs_path)

            # AST no-op gate on target if original existed
            if target.exists():
                orig_src = None
                for s in snapshots:
                    if s.path == target and s.existed and s.content is not None:
                        orig_src = s.content.decode("utf-8", errors="ignore"); break
                if orig_src is not None:
                    new_src = target.read_text(encoding="utf-8", errors="ignore")
                    if ast_equal(orig_src, new_src):
                        print("[Gate] No-op/cosmetic change detected (AST-equal). Rejecting.")
                        rollback(snapshots); continue

            ok_py = run_pytest(args.pytest_timeout)
            if not ok_py:
                print("[Gate] pytest failed. Rolling back."); rollback(snapshots); continue

            b1 = run_bench(args.determinism, args.bench_timeout)
            rate_equal = abs(b1.rate - b0.rate) < 1e-9
            rate_ok = b1.rate >= args.min_rate
            speed_ok = (b1.latency_s <= b0.latency_s * (1.0 - args.min_equal_rate_speedup)) if rate_equal else (b1.rate > b0.rate)

            micro_ok = True
            if args.micro_gate:
                m1 = run_micro(3, 90)
                micro_ok = (m1.latency_ms <= m0.latency_ms * (1.0 - args.micro_speedup)) or (m1.steps <= m0.steps)

            bench_str = f"[Bench] {'rate equal' if rate_equal else f'rate {b1.rate:.3f} vs {b0.rate:.3f}'}; " \
                        f"{'latency OK' if speed_ok else 'latency not fast enough'} " \
                        f"({b1.latency_s:.3f}s {'≤' if speed_ok else '>'} {b0.latency_s*(1.0-args.min_equal_rate_speedup):.3f}s)"
            micro_str = "" if not args.micro_gate else f"; [Micro] {'OK' if micro_ok else 'NO'}"
            print(f"[Gate] {bench_str}{micro_str}; [Smoke] {'OK' if ok_py else 'NO'}")

            if rate_ok and (not rate_equal or speed_ok) and (not args.micro_gate or micro_ok):
                if target.exists():
                    bkp = backup_file(target)
                    print(f"[Applied] Original backed up to {bkp.as_posix()}; target updated.")
                else:
                    print("[Applied] Changes kept (new files created).")
                b0 = b1
                if args.micro_gate: m0 = m1
            else:
                print("[Gate] Rejected by thresholds. Rolling back.")
                rollback(snapshots)
        except Exception as e:
            print(f"[Cycle {cycle}] Error during apply/test: {e}")
            try: rollback(snapshots)
            except Exception: pass

    print("\n[Done] Gated loop finished.")

if __name__ == "__main__":
    main()
