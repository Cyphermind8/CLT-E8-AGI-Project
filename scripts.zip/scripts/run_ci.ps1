﻿param(
    [int]$Cycles = 30,
    [int]$Minutes = 180,
    [switch]$Strict
)

$ErrorActionPreference = 'Stop'

function Invoke-Preflight {
    Write-Host "[*] Running preflight..."
    $p = & python .\scripts\preflight.py 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host $p
        throw "Preflight failed."
    }
    Write-Host "[✓] Preflight compile OK."
}

function New-SessionId {
    (Get-Date -Format 'yyyyMMdd_HHmmss')
}

# --- main ---
Invoke-Preflight

$sessionId = New-SessionId
$deadline  = (Get-Date).AddMinutes($Minutes)
$reportDir = Join-Path -Path (Resolve-Path ".") -ChildPath "reports"
if (-not (Test-Path $reportDir)) { New-Item -ItemType Directory -Path $reportDir | Out-Null }

$session = [ordered]@{
    session_id = "ci_session_$sessionId"
    cycles     = $Cycles
    minutes    = $Minutes
    strict     = [bool]$Strict
    started_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    results    = @()
}

# Detect --strict support safely
$strictSupported = $false
if ($Strict) {
    try {
        $helpText = (& python self_mod\gated_loop.py -h 2>&1 | Out-String)
        if ($helpText -match "--strict") {
            $strictSupported = $true
            Write-Host "[=] gated_loop.py supports --strict; enabling strict mode."
        } else {
            Write-Host "[!] gated_loop.py does not support --strict; continuing without it."
        }
    } catch {
        Write-Host "[!] Could not determine --strict support; continuing without it."
    }
}

for ($i = 1; $i -le $Cycles; $i++) {
    if ((Get-Date) -gt $deadline) {
        Write-Host "[!] Time limit reached; stopping after cycle $($i-1)."
        break
    }

    Write-Host "[CYCLE $i] starting..."
    $start = Get-Date

    $args = @("self_mod\gated_loop.py", "--cycle", $i)
    if ($strictSupported) { $args += "--strict" }

    # Run gated loop and capture all output
    $output = & python @args 2>&1
    $exit   = $LASTEXITCODE
    $dur    = (Get-Date) - $start
    $secs   = [Math]::Round($dur.TotalSeconds, 1)

    Write-Host ("[CYCLE {0}] duration={1}s exit={2}" -f $i, $secs, $exit)

    # Pretty print some common lines for quick visibility
    if ($output -is [System.Array]) {
        $output | ForEach-Object {
            if ($_ -match "AllowedFunctions" -or $_ -match "Using transform-menu" -or $_ -match "Patch committed" -or $_ -match "No safe improvement" -or $_ -match "Patch schema rejected" -or $_ -match "Traceback") {
                Write-Host $_
            }
        }
    } else {
        Write-Host $output
    }

    # Store record
    $session.results += [ordered]@{
        cycle     = $i
        started   = $start.ToString("HH:mm:ss")
        duration  = "$secs`s"
        exit_code = $exit
        stdout    = $output
    }
}

$session.completed_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
$reportPath = Join-Path $reportDir "$($session.session_id).json"
$session | ConvertTo-Json -Depth 6 | Out-File -FilePath $reportPath -Encoding UTF8

Write-Host "[✓] CI session complete. Summary: $reportPath"
