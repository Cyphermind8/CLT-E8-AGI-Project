param(
  [switch]$WhatIf
)

# Quarantine junk candidate files that break compile:
#   • *_cand_*.py under src\
#   • Any .py containing markdown fences or "No changes required."
# Moves them to quarantine\<timestamp>\ preserving relative paths.

$ErrorActionPreference = "Stop"
$root = (Resolve-Path .).Path
$stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
$qroot = Join-Path $root ("quarantine\" + $stamp)

# Discover junk files
$cand = @()
$cand += Get-ChildItem -Path (Join-Path $root "src") -Filter "*_cand_*.py" -Recurse -ErrorAction SilentlyContinue

$sus = Get-ChildItem -Path (Join-Path $root "src") -Filter "*.py" -Recurse -ErrorAction SilentlyContinue |
  Where-Object {
    try {
      Select-String -Path $_.FullName -SimpleMatch -Pattern "```","```python","No changes required." -Quiet
    } catch { $false }
  }

$toMove = ($cand + $sus) | Sort-Object FullName -Unique

if ($toMove.Count -eq 0) {
  Write-Host "[=] No junk files found. Workspace looks clean."
  return
}

Write-Host ("[*] Quarantining {0} junk file(s) into {1}" -f $toMove.Count, $qroot)

foreach ($f in $toMove) {
  $rel = $f.FullName.Substring($root.Length).TrimStart('\','/')
  $dest = Join-Path $qroot $rel
  $destDir = Split-Path $dest -Parent
  if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir | Out-Null }
  if ($WhatIf) {
    Write-Host ("[DRY] Would move: {0} -> {1}" -f $f.FullName, $dest)
  } else {
    Move-Item -LiteralPath $f.FullName -Destination $dest -Force
    Write-Host ("[→] Moved: {0}" -f $rel)
  }
}

Write-Host "[✓] Quarantine complete."
Write-Host ("    Review at: {0}" -f $qroot)
