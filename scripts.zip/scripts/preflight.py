# Preflight compile that ignores junk candidates.
# Only compiles .py under src/ that do NOT contain '_cand_' and are not under 'quarantine/'.
from __future__ import annotations
import os, sys, py_compile

ROOT = os.path.abspath(os.path.dirname(__file__) + "/..")
SRC  = os.path.join(ROOT, "src")

def iter_files():
    for dirpath, dirnames, filenames in os.walk(SRC):
        # skip quarantine folders if any are under src/
        if "quarantine" in dirpath.split(os.sep):
            continue
        for fn in filenames:
            if not fn.endswith(".py"): 
                continue
            if "_cand_" in fn:
                continue
            yield os.path.join(dirpath, fn)

def main():
    fails = []
    for path in iter_files():
        try:
            py_compile.compile(path, doraise=True)
        except py_compile.PyCompileError as e:
            sys.stderr.write(f"*** Error compiling '{os.path.relpath(path, ROOT)}'...\n{e.msg}\n")
            fails.append(path)
    if fails:
        sys.stderr.write(f"[x] Preflight failed on {len(fails)} file(s).\n")
        return 1
    print("[✓] Preflight compile OK.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
